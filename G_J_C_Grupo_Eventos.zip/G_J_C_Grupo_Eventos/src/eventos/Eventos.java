package eventos;

public class Evento {
	int id;
	String name;
	String fecha;
	int horaInicio ;
	
	public Evento(int id, String name, String fecha,int horaInicio) {
		
		this.id = id;
		this.name =  name;
		this.fecha = fecha;
		this.horaInicio =  horaInicio;
		
	
	}
	
	




	@Override
	public String toString() {
		return "Eventos [id=" + id + ", name=" + name + ", fecha=" + fecha + "]";
	}

	
	
	

}

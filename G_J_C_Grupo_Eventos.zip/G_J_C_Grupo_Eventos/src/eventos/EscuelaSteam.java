package eventos;
import java.util.Scanner;

public class EscuelaSteam {
	
	public static void main(String[]args) {
		
		Scanner teclado = new Scanner(System.in);
		int menu;
		boolean banderita = true;

		String title = "==================================================\n"
				+ "|||| BIENVENIDOS AL CALENDARIO DE EVENTOS UEM |||| "
				+ "\n==================================================";


		System.out.println();

		while(banderita) {
			System.out.println("C:EventsUe > ");

			String titleUpper = title.toUpperCase();
			System.out.println();

			String development= "D e v e l o p m e n t   b y   C a r m e n  ,  J o s u e  ,  G i n o";
			String develoUpper= development.toUpperCase();
			System.out.println(title);
			System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
			System.out.println(develoUpper  );
			System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
			System.out.println();
			System.out.println("1) EVENTO UEM");
			System.out.println("2) AÑADIR EVENTO UEM");
			System.out.println("3) MODIFICAR EVENTO UEM");
			System.out.println("4) ELIMINAR EVENTO UEM");
			System.out.println("5) HELP UEM");
			
			
			menu  = teclado.nextInt();

			switch(menu) {
			

			case 1:
				boolean flag = true;
				
				while(flag) {
					
					
					System.out.println("C:EventsUe >Evento_Uem");
					
					System.out.println();

					System.out.println("1) VER EVENTO UEM");
					
					System.out.println("2) VER POR FECHA UEM  ");
					
					System.out.println("3) EXIT");
					
					
					int opcionesMenu = teclado.nextInt();
					
					switch(opcionesMenu){
					
						case 1:
							System.out.println();

							System.out.println("C:EventsUe >Evento_Uem\\Ver_Evento_Uem");
							
							System.out.println();

							System.out.println("MOSTRANDO EVENTOS UEM");
							
							
							System.out.println();


							break;
							
						case 2:
							System.out.println("MOSTRANDO CALENDARIO POR FECHA");

							break;
						case 3:
							System.out.println("SALIENDO....");
							
							System.out.println();
							
							if(opcionesMenu == 3) {
								flag = false;
							}

							break;
						default :
							System.out.println("INGRESA VALORES CORRECTOS");

							break;
							
					}
					
						
				}
				
			break;
			
			case 2:
				boolean flag2 = true;
				
				while(flag2) {
					System.out.println("C:EventsUe >Añadir_Evento_Uem");
					System.out.println("1) INGRESAR NUEVO EVENTO UEM");

					int opcionesMenu2 = teclado.nextInt();
					switch(opcionesMenu2) {
					case 1:
						System.out.println("Nombre:");
						String name = teclado.next();
						System.out.println("Fecha (0/0/0):");
						String FamilyName = teclado.next();
						System.out.println("Hora de Inicio:");
						int starTime = teclado.nextInt();
						System.out.println("Hora de Fin:");
						int endTime = teclado.nextInt();
						System.out.println("Lugar:");
						String place = teclado.next();
						System.out.println("Publico objetivo:");
						String user = teclado.next();
						System.out.println("Url");
						String url = teclado.next();
						break;
						
						default:
							System.out.println("INGRESA VALORES CORRECTOS");
						break;
					}

				}
				
			break;
			case 3:
				System.out.println("EVENTO UEM");
			break;
			case 4:
				System.out.println("EVENTO UEM");
			break;
			case 5:
				System.out.println("EVENTO UEM");
			break;
			
			default:
				System.out.println("ingresa valores correctos. '5' help");
				break;
			}
			
		}
		
		
		teclado.close();
		
	}

}
